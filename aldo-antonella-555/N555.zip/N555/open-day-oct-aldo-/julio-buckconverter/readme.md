Agregar la info
